export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { name, sector, msg, city } = req.body;
  if (!name || !msg) return res.status(400).json({ error: 'Missing required fields' });

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1200,
        messages: [{
          role: 'user',
          content: `You are a world-class DOOH (Digital Out-of-Home) creative director. Generate exactly 3 distinct ad variants for a digital outdoor screen. Each variant must have a completely different creative personality.

Business: ${name}
Sector: ${sector}
Message/Offer: ${msg}
City: ${city}

RESPOND WITH ONLY VALID JSON — no markdown, no backticks, no explanation:
{
  "variants": [
    {
      "label": "Short creative direction name (2-3 words)",
      "headline": "Max 4 bold words — punchy, immediate, readable at 10m",
      "subline": "Max 8 words — support the headline, include the key offer",
      "cta": "2-3 words action phrase",
      "bg_color": "#hex — saturated, strong background",
      "text_color": "#hex — must contrast strongly with bg_color (min 4.5:1 ratio)",
      "accent_color": "#hex — vibrant accent for CTA button and decorative bar",
      "mood": "bold | elegant | vibrant"
    }
  ]
}

Rules:
- Variant 1: Bold/modern — dark background, strong contrast, direct message
- Variant 2: Elegant/premium — refined palette, sophisticated copy, upscale feel
- Variant 3: Vibrant/friendly — warm energetic colors, approachable tone
- ALL text optimised for 10m outdoor readability (short, strong, immediate)
- Colors must be sector-appropriate and high-contrast
- Never use near-white bg with white text or near-black bg with black text`
        }]
      })
    });

    const data = await response.json();
    if (data.error) return res.status(500).json({ error: data.error.message });

    const text = data.content[0].text.trim().replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(text);
    res.status(200).json(parsed);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
